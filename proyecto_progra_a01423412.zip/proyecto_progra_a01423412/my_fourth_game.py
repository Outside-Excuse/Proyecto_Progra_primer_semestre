import pygame
pygame.init()

win = pygame.display.set_mode((500,480))

pygame.display.set_caption("first game")

walkRight = [pygame.image.load('R1.png'), pygame.image.load('R2.png'), pygame.image.load('R3.png'), pygame.image.load('R4.png'), pygame.image.load('R5.png'), pygame.image.load('R6.png'), pygame.image.load('R7.png'), pygame.image.load('R8.png'), pygame.image.load('R9.png')]
walkLeft = [pygame.image.load('L1.png'), pygame.image.load('L2.png'), pygame.image.load('L3.png'), pygame.image.load('L4.png'), pygame.image.load('L5.png'), pygame.image.load('L6.png'), pygame.image.load('L7.png'), pygame.image.load('L8.png'), pygame.image.load('L9.png')]
bg = pygame.image.load('bg.jpg')
char = pygame.image.load('standing.png')

clock = pygame.time.Clock() #---------------------------------------------------------Change the FPS of the GAME
 
class player(object):   #-----------------------------------------------------------------Metimos todas nuestras variables que definen a nuestro jugados en una clase llamada player y ahora son un atrivuto de nuestra clase
    def __init__(self,x,y,width,height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 5
        self.isJump = False
        self.jumpCount = 10
        self.left = False
        self.right = False
        self.walkCount = 0
    def draw(self,win): #--------------------------------------------------------------------------------funcion donde dibujamos a nuestro personaje
        if self.walkCount + 1 >= 27:
            self.walkCount = 0
        
        if self.left:
            win.blit(walkLeft[self.walkCount//3], (self.x,self.y)) 
            self.walkCount += 1
        elif self.right:
            win.blit(walkRight[self.walkCount//3], (self.x,self.y))
            self.walkCount += 1
        else:
            win.blit(char,(self.x,self.y))




def redraGameWindow(): #----------------------------------------------------------------------Esta funcion pinta el mundo/mejor dicho, realcia nuestras impresiones de frames
    win.blit(bg,(0,0))
    eugeo.draw(win)
    # win.fill((0,0,0))

    #pygame.draw.rect(win, (255,0,0), (x,y,width,height))
    pygame.display.update()

#main loop
eugeo = player(300,410,64,46)
run = True 
while run:
    #pygame.time.delay(10)
    clock.tick(50)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    Keys = pygame.key.get_pressed()   #---------------------------------------------------------------------------las teclas que se utilizan en nuestro programa
    if Keys[pygame.K_LEFT] and eugeo.x > eugeo.vel:
        eugeo.x -= eugeo.vel
        eugeo.left = True
        eugeo.right = False
    elif Keys[pygame.K_RIGHT] and eugeo.x < 500 -eugeo.width - eugeo.vel:
        eugeo.x += eugeo.vel
        eugeo.left = False
        eugeo.right = True
    else:
        eugeo.left = False
        eugeo.right = False
        eugeo.walkCount = 0

    if not(eugeo.isJump):
        if Keys[pygame.K_SPACE]:
            eugeo.isJump = True
            eugeo.left = False
            eugeo.right = False
            eugeo.walkCount = 0
    else:  #---------------------------------------------------------------------------------------------------SALTO
        if eugeo.jumpCount >= -10:
            neg = 1
            if eugeo.jumpCount < 0:
                neg = -1
            eugeo.y -= (eugeo.jumpCount ** 2) *0.4 * neg
            eugeo.jumpCount -=1
        else:
            eugeo.isJump = False
            eugeo.jumpCount = 10

    redraGameWindow() #------------------------------------------------------------------------------------------En esta funcion se encuentran nuestros "Draw (dibujos)"
    
    
pygame.quit()