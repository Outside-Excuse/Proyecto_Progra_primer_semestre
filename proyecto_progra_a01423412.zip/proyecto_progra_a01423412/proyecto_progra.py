#Smooth Movement in pygame

#imports

import pygame, sys


from pygame import image
from pygame import transform

from pygame.constants import KEYDOWN, KEYUP, MOUSEBUTTONDOWN
from pygame import*
from pygame.event import Event
from pygame.time import Clock
import math  
    
a = math.pi / 6
     

#constants
WIDTH, HEIGHT = 800, 600
TITLE = "El FONTANERO"
fondo = image.load("background.jpg") # cargar imagen

fondo = transform.scale(fondo,(800,600)) # re-dimensionar imagen

#pygame initialization
pygame.init() # este preparado para mostrar elementos en pantalla
#mixer.init()

myFont = font.SysFont("impact", 30)
win = pygame.display.set_mode((WIDTH,HEIGHT)) # resolucion


 #---------------------fondo
pygame.display.set_caption(TITLE)
Clock = pygame.time.Clock()
frames = 0
angulo = 0.0

#sound = mixer.Sound("coco.mp3")
#Player Class
boton = Rect(100,100,150,50)
class Player:
    def __init__(self,x,y):
        self.rect = pygame.Rect(x,y,32,32)
        self.x = int(x)
        self.y = int(y)
        self.color = (250,120,60)
        self.velx = 0
        self.vely = 0
        self.left_pressed = False
        self.right_pressed = False
        self.up_pressed = False
        self.down_pressed = False
        self.speed = 4


    def draw(self,win):
        pygame.draw.circle(win,(50,150,200), (50,50), 50,1 ) #hacer circulos
        #pygame.draw.circle(win,(50,150,200), (400,300), 50,0 ) # hacer circulos
        pygame.draw.rect(win,self.color, self.rect)
        #pygame.draw.rect(win, (180,120,80), (100,500,600,50), 2) # hacer rectangulos
       # pygame.draw.line(win, (100,200,100), (0,600), (800,0), 3) # hacer lineas 
        

    def update(self, angulo):
        self.velx = 0
        self.vely = 0
        
        if self.left_pressed and not self.right_pressed:
            self.velx = -self.speed
            #sound.play()
        if self.right_pressed and not self.left_pressed:
            self.velx = self.speed
        if self.up_pressed and not self.down_pressed:
            angulo = 0.001
            self.vely = self.speed -math.sin(angulo)*200
        if self.down_pressed and not self.up_pressed:
            self.vely = self.speed

        self.x += self.velx
        self.y += self.vely

        self.rect = pygame.Rect(self.x,self.y, 32,32)

def pintar_boton(boton, palabra,win):
        if boton.collidepoint(mouse.get_pos()):
            draw.rect(win,(237,128,19), boton, 0)
        else:
            draw.rect(win,(70,189,34), boton, 0)
        texto = myFont.render(palabra, True, (220,220,220))
        win.blit(texto,(100+(boton.width-texto.get_width())/2,100+(boton.height-texto.get_height())/2))
        


#Player Initialization
player = Player(WIDTH/2, HEIGHT/2)

 

#Main Loop
while True:
    for event in pygame.event.get(): #obtiene la lista de los eventos de nuestro programa
        if event.type == pygame.QUIT: #identificamos si el usuario quiere salir del programa
            pygame.quit()
            sys.exit() #se llama al sistema para terminar el programa
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                player.left_pressed = True
            if event.key == pygame.K_d:
                player.right_pressed = True
            if event.key == pygame.K_w:
                angulo = 0.00001
                player.up_pressed = True
            if event.key == pygame.K_s:
                player.down_pressed = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                angulo = 0.0
                player.left_pressed = False
            if event.key == pygame.K_d:
                player.right_pressed = False
            if event.key == pygame.K_w:
                player.up_pressed = False
            if event.key == pygame.K_s:
                player.down_pressed = False
        if event.type == MOUSEBUTTONDOWN and event.button==1:
            if boton.collidepoint(mouse.get_pos()):
                print(1)
    if angulo > 0: angulo = angulo + 0.01
    win.blit(fondo, (0,0))            
    pintar_boton(boton,"Aceptar",win)

    
    num = myFont.render(str(frames), True, (50,70,80))  
    win.blit(num,(100,10))                                  #myFont.render("hola Bienvenidos", True, (50,70,80))
    frames += 1
    #Draw
    #          R  G  B   (0-255)
    #win.fill(fondo, (0,0))
    
   
    player.draw(win)
    
    #update
    player.update(angulo)
    #win.blit(fondo, (0,0))
    pygame.display.flip() # manda a pantalla lo que se quiera dibujar

    Clock.tick(120)

"""
evento continuo: se da a lo largo de varios frames, y en ese lapso siempre sera detectado

el evento discreto se detecta en un solo frame 
"""
