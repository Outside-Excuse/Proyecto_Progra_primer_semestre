import sys
from pygame import *
import math

import pygame
from pygame.constants import KEYDOWN, K_x
from pygame.draw import line 
init()
screen = display.set_mode((800,600))
floor = line(screen, (0,0,0), (0,500), (800,500), 2 )
x,y = 100,400
angulo = 0.0
while True:
    screen.fill((255,255,255))
    for event in pygame.event.get(): #obtiene la lista de los eventos de nuestro programa
        if event.type == pygame.QUIT: #identificamos si el usuario quiere salir del programa
            pygame.quit()
            sys.exit() #se llama al sistema para terminar el programa:
        
    if event.type == KEYDOWN and event.key == K_x:
         angulo = 0.001
    y = 400 - math.sin(angulo)*300
    draw.rect(screen, (100,150,200), (x,y,30,100), 0)
    draw.floor
    if angulo > 0:
        angulo = angulo + 0.0001

    if angulo >= math.pi: 
        angulo = 0.0
    display.flip()
