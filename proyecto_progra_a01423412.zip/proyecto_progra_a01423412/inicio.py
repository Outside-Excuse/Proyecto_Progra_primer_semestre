# Alejandro Hidalgo Badillo / A01423412 Proyecto final TC1028.4
import nivel1
import pygame
import sys
def mostrar_boton(screen,boton,botonP,botonR,x,y): # definimos boton 
    if boton.collidepoint(pygame.mouse.get_pos()):
        screen.blit(botonP, (x,y))
        
    else:
        screen.blit(botonR, (x,y))
        
def inicio():
    pygame.init()
    screen = pygame.display.set_mode((1000,480))
    mort = pygame.font.SysFont('Bauhaus 93',80)
    CSI = mort.render('CSI MIAMI',True,(50,15,10))
    datos = mort.render('Alejandro Hidalgo Badillo A01423412',True,(50,15,10))
    area_boton = pygame.Rect(370,220,250,150)
    botonR = pygame.image.load('boton_startR.png')
    botonP = pygame.image.load('boton_startP.png')
    fondo = pygame.image.load('fondo_miami.png')
    while True:
        screen.blit(fondo, (0,0))
        for e in pygame.event.get():
            if e.type == pygame.QUIT: sys.exit()
            if e.type == pygame.MOUSEBUTTONDOWN and e.button==1:
                if area_boton.collidepoint(pygame.mouse.get_pos()):
                    print('clic')
                    nivel1.nivel()
        screen.blit(CSI, (305,100))
        screen.blit(datos, (50,10))
        mostrar_boton(screen,area_boton,botonP,botonR,270,200) #asiganmos posiciones en nuestra definicion del diseño de boton
        pygame.display.flip()

inicio()