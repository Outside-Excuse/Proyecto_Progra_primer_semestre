# Alejandro Hidalgo Badillo / A01423412 Proyecto final TC1028.4
import pygame
from pygame import image
def thief4(puntaje3):
    pygame.init()

    win = pygame.display.set_mode((1000,480))

    pygame.display.set_caption("CSI MIAMI")

    walkRight = [pygame.image.load('R1.png'), pygame.image.load('R2.png'), pygame.image.load('R3.png'), pygame.image.load('R4.png'), pygame.image.load('R5.png'), pygame.image.load('R6.png'), pygame.image.load('R7.png'), pygame.image.load('R8.png'), pygame.image.load('R9.png')]
    walkLeft = [pygame.image.load('L1.png'), pygame.image.load('L2.png'), pygame.image.load('L3.png'), pygame.image.load('L4.png'), pygame.image.load('L5.png'), pygame.image.load('L6.png'), pygame.image.load('L7.png'), pygame.image.load('L8.png'), pygame.image.load('L9.png')]
    bgfondo = pygame.image.load('Katana.jpeg')
    bj = pygame.image.load('miami.png')
    miami= pygame.transform.scale(bj, (1000, 480))
    bg = pygame.transform.scale(bgfondo, (1000, 480))

    #char = pygame.image.load('standing.png')

    clock = pygame.time.Clock() #---------------------------------------------------------Change the FPS of the GAME
    bulletSound = pygame.mixer.Sound("bullet.wav")
    hitSound = pygame.mixer.Sound("hit.wav")
    #music = pygame.mixer.music.load("Bella.mp3")
    #pygame.mixer.music.play(-1)
    puntaje4 = puntaje3
    
    class player(object):   #-----------------------------------------------------------------Metimos todas nuestras variables que definen a nuestro jugados en una clase llamada player y ahora son un atrivuto de nuestra clase
        def __init__(self,x,y,width,height):
            self.x = x
            self.y = y
            self.width = width
            self.height = height
            self.vel = 5
            self.isJump = False
            self.jumpCount = 10
            self.left = False
            self.right = False
            self.walkCount = 0
            self.standing = True
            self.hitbox = (self.x + 17, self.y+11, 29,52) #hitbox


        def draw(self,win): #--------------------------------------------------------------------------------funcion donde dibujamos a nuestro personaje
            if not(self.standing):
                if self.walkCount + 1 >= 27:
                    self.walkCount = 0
                
                if self.left:
                    win.blit(walkLeft[self.walkCount//3], (self.x,self.y)) 
                    self.walkCount += 1
                elif self.right:
                    win.blit(walkRight[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1
            else:
                if self.right:
                    win.blit(walkRight[0], (self.x,self.y))
                else:
                    win.blit(walkLeft[0], (self.x,self.y))
            self.hitbox = (self.x + 17, self.y+11, 29,52) #redefinimos hitbox
            pygame.draw.rect(win, (255,0,0), self.hitbox, 2) #dibujamos hitbox
        def hit(self):#----------------------------------------------------------------------------------------------------funcion donde se lleva a cabo el golpe hacia nuestro jugador
            self.isJump = False
            self.jumpCount = 10
            self.x = 60
            self.y = 410
            self.walkCount = 0
            font1 = pygame.font.SysFont("comicsans", 100)
            text = font1.render ("-5",1,(0,0,255))
            win.blit(text, (500-(text.get_width()/2),200))
            pygame.display.update()
            i = 0
            while i < 100:
                pygame.time.delay(10)
                i += 1
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        i = 101
                        pygame.quit()


    class projectile(object): #----------------------------------------------------------------------------------creamos nuestra clase de proyectil para poder definir nuestra bala
        def __init__(self,x,y,radio,color,cara):#---------------------------------------------------------------cara sirve para decirnos si nmuestras balas se mueven izquierda o derecha
            self.x = x
            self.y = y
            self.radio = radio
            self.color = color
            self.cara = cara
            self.vel = 8*cara
        def draw(self,win):#---------------------------------------------------------------------------------------dibujamos la bala
            pygame.draw.circle(win,self.color,(self.x,self.y),self.radio)


    class enemy(object): #--------------------------------------------------------------------------------------------creamos a nuestro enemigo del juego 
        walkRight = [pygame.image.load('R1E.png'), pygame.image.load('R2E.png'), pygame.image.load('R3E.png'), pygame.image.load('R4E.png'), pygame.image.load('R5E.png'), pygame.image.load('R6E.png'), pygame.image.load('R7E.png'), pygame.image.load('R8E.png'), pygame.image.load('R9E.png'), pygame.image.load('R10E.png'), pygame.image.load('R11E.png')]
        walkLeft = [pygame.image.load('L1E.png'), pygame.image.load('L2E.png'), pygame.image.load('L3E.png'), pygame.image.load('L4E.png'), pygame.image.load('L5E.png'), pygame.image.load('L6E.png'), pygame.image.load('L7E.png'), pygame.image.load('L8E.png'), pygame.image.load('L9E.png'), pygame.image.load('L10E.png'), pygame.image.load('L11E.png')]
        
        def __init__(self,x,y,width,height,end):
            self.x = x
            self.y = y
            self.width = width
            self.height = height
            self.end = end
            self.path = [self.x,self.end]
            self.walkCount = 0
            self.vel = 3
            self.hitbox = (self.x + 17, self.y+2, 31,57) #hitbox
            self.health = 10
            self.visible = True
        def draw(self,win): #----------------------------------------------------------------------------------------------dibujamos al enemigo
            self.move()
            if self.visible:
                if self.walkCount +1 >= 33:
                    self.walkCount = 0
                if self.vel > 0:
                    win.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1
                else:
                    win.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1

                pygame.draw.rect(win, (255,0,0), (self.hitbox[0], self.hitbox[1]-20,50, 10))
                pygame.draw.rect(win, (0,255,0), (self.hitbox[0], self.hitbox[1]-20,50 - (5 * (10-self.health)), 10))
                self.hitbox = (self.x + 17, self.y+2, 31,57) #redefinimos hitbox
                pygame.draw.rect(win, (255,0,0), self.hitbox, 2) #dibujamos hitbox
        def hit(self):
            if self.health > 0:
                self.health -= 1
                print("hit")
            else:
                self.visible = False


        def move(self):
            if self.vel > 0: #---------------------------nuestro enemigo va a la derecha
                if self.x +self.vel < self.path[1]:
                    self.x += self.vel
                else:
                    self.vel = self.vel * -1  
                    self.walkCount = 0
            else:  #-----------------------------------nuestro enemigo va a la izquierda 
                if self.x - self.vel > self.path[0]:
                    self.x += self.vel
                else:
                    self.vel = self.vel * -1
                    self.walkCount = 0
    #====================================================================================================================inicio enemigo 2
        
    class enemy2(object): #--------------------------------------------------------------------------------------------creamos a nuestro enemigo del juego 
        walkRight = [pygame.image.load('R1E.png'), pygame.image.load('R2E.png'), pygame.image.load('R3E.png'), pygame.image.load('R4E.png'), pygame.image.load('R5E.png'), pygame.image.load('R6E.png'), pygame.image.load('R7E.png'), pygame.image.load('R8E.png'), pygame.image.load('R9E.png'), pygame.image.load('R10E.png'), pygame.image.load('R11E.png')]
        walkLeft = [pygame.image.load('L1E.png'), pygame.image.load('L2E.png'), pygame.image.load('L3E.png'), pygame.image.load('L4E.png'), pygame.image.load('L5E.png'), pygame.image.load('L6E.png'), pygame.image.load('L7E.png'), pygame.image.load('L8E.png'), pygame.image.load('L9E.png'), pygame.image.load('L10E.png'), pygame.image.load('L11E.png')]
        
        def __init__(self,x,y,width,height,end):
            self.x = x
            self.y = y
            self.width = width
            self.height = height
            self.end = end
            self.path = [self.x,self.end]
            self.walkCount = 0
            self.vel = 3
            self.hitbox = (self.x + 17, self.y+2, 31,57) #hitbox
            self.health = 10
            self.visible = True
        def draw(self,win): #----------------------------------------------------------------------------------------------dibujamos al enemigo
            self.move()
            if self.visible:
                if self.walkCount +1 >= 33:
                    self.walkCount = 0
                if self.vel > 0:
                    win.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1
                else:
                    win.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1

                pygame.draw.rect(win, (255,0,0), (self.hitbox[0], self.hitbox[1]-20,50, 10))
                pygame.draw.rect(win, (0,255,0), (self.hitbox[0], self.hitbox[1]-20,50 - (5 * (10-self.health)), 10))
                self.hitbox = (self.x + 17, self.y+2, 31,57) #redefinimos hitbox
                pygame.draw.rect(win, (255,0,0), self.hitbox, 2) #dibujamos hitbox
        def hit(self):
            if self.health > 0:
                self.health -= 1
                print("hit")
            else:
                self.visible = False


        def move(self):
            if self.vel > 0: #---------------------------nuestro enemigo va a la derecha
                if self.x +self.vel < self.path[1]:
                    self.x += self.vel
                else:
                    self.vel = self.vel * -1  
                    self.walkCount = 0
            else:  #-----------------------------------nuestro enemigo va a la izquierda 
                if self.x - self.vel > self.path[0]:
                    self.x += self.vel
                else:
                    self.vel = self.vel * -1
                    self.walkCount = 0

    #================================================================================================================fin de enemigo2


    #====================================================================================================================inicio enemigo3
        
    class enemy3(object): #--------------------------------------------------------------------------------------------creamos a nuestro enemigo del juego 
        walkRight = [pygame.image.load('R1E.png'), pygame.image.load('R2E.png'), pygame.image.load('R3E.png'), pygame.image.load('R4E.png'), pygame.image.load('R5E.png'), pygame.image.load('R6E.png'), pygame.image.load('R7E.png'), pygame.image.load('R8E.png'), pygame.image.load('R9E.png'), pygame.image.load('R10E.png'), pygame.image.load('R11E.png')]
        walkLeft = [pygame.image.load('L1E.png'), pygame.image.load('L2E.png'), pygame.image.load('L3E.png'), pygame.image.load('L4E.png'), pygame.image.load('L5E.png'), pygame.image.load('L6E.png'), pygame.image.load('L7E.png'), pygame.image.load('L8E.png'), pygame.image.load('L9E.png'), pygame.image.load('L10E.png'), pygame.image.load('L11E.png')]
        
        def __init__(self,x,y,width,height,end):
            self.x = x
            self.y = y
            self.width = width
            self.height = height
            self.end = end
            self.path = [self.x,self.end]
            self.walkCount = 0
            self.vel = 7
            self.hitbox = (self.x + 17, self.y+2, 31,57) #hitbox
            self.health = 10
            self.visible = True
        def draw(self,win): #----------------------------------------------------------------------------------------------dibujamos al enemigo
            self.move()
            if self.visible:
                if self.walkCount +1 >= 33:
                    self.walkCount = 0
                if self.vel > 0:
                    win.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1
                else:
                    win.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1

                pygame.draw.rect(win, (255,0,0), (self.hitbox[0], self.hitbox[1]-20,50, 10))
                pygame.draw.rect(win, (0,255,0), (self.hitbox[0], self.hitbox[1]-20,50 - (5 * (10-self.health)), 10))
                self.hitbox = (self.x + 17, self.y+2, 31,57) #redefinimos hitbox
                pygame.draw.rect(win, (255,0,0), self.hitbox, 2) #dibujamos hitbox
        def hit(self):
            if self.health > 0:
                self.health -= 1
                print("hit")
            else:
                self.visible = False


        def move(self):
            if self.vel > 0: #---------------------------nuestro enemigo va a la derecha
                if self.x +self.vel < self.path[1]:
                    self.x += self.vel  
                else:
                    self.vel = self.vel * -1  
                    self.walkCount = 0
            else:  #-----------------------------------nuestro enemigo va a la izquierda 
                if self.x - self.vel > self.path[0]:
                    self.x += self.vel
                else:
                    self.vel = self.vel * -1
                    self.walkCount = 0

    #================================================================================================================fin de enemigo3

    #====================================================================================================================inicio enemigo4
        
    class enemy4(object): #--------------------------------------------------------------------------------------------creamos a nuestro enemigo del juego 
        walkRight = [pygame.image.load('R1E.png'), pygame.image.load('R2E.png'), pygame.image.load('R3E.png'), pygame.image.load('R4E.png'), pygame.image.load('R5E.png'), pygame.image.load('R6E.png'), pygame.image.load('R7E.png'), pygame.image.load('R8E.png'), pygame.image.load('R9E.png'), pygame.image.load('R10E.png'), pygame.image.load('R11E.png')]
        walkLeft = [pygame.image.load('L1E.png'), pygame.image.load('L2E.png'), pygame.image.load('L3E.png'), pygame.image.load('L4E.png'), pygame.image.load('L5E.png'), pygame.image.load('L6E.png'), pygame.image.load('L7E.png'), pygame.image.load('L8E.png'), pygame.image.load('L9E.png'), pygame.image.load('L10E.png'), pygame.image.load('L11E.png')]
        
        def __init__(self,x,y,width,height,end):
            self.x = x
            self.y = y
            self.width = width
            self.height = height
            self.end = end
            self.path = [self.x,self.end]
            self.walkCount = 0
            self.vel = 20
            self.hitbox = (self.x + 17, self.y+2, 31,57) #hitbox
            self.health = 10
            self.visible = True
        def draw(self,win): #----------------------------------------------------------------------------------------------dibujamos al enemigo
            self.move()
            if self.visible:
                if self.walkCount +1 >= 33:
                    self.walkCount = 0
                if self.vel > 0:
                    win.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1
                else:
                    win.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1

                pygame.draw.rect(win, (255,0,0), (self.hitbox[0], self.hitbox[1]-20,50, 10))
                pygame.draw.rect(win, (0,255,0), (self.hitbox[0], self.hitbox[1]-20,50 - (5 * (10-self.health)), 10))
                self.hitbox = (self.x + 17, self.y+2, 31,57) #redefinimos hitbox
                pygame.draw.rect(win, (255,0,0), self.hitbox, 2) #dibujamos hitbox
        def hit(self):
            if self.health > 0:
                self.health -= 1
                print("hit")
            else:
                self.visible = False


        def move(self):
            if self.vel > 0: #---------------------------nuestro enemigo va a la derecha
                if self.x +self.vel < self.path[1]:
                    self.x += self.vel  
                else:
                    self.vel = self.vel * -1  
                    self.walkCount = 0
            else:  #-----------------------------------nuestro enemigo va a la izquierda 
                if self.x - self.vel > self.path[0]:
                    self.x += self.vel
                else:
                    self.vel = self.vel * -1
                    self.walkCount = 0

    #================================================================================================================fin de enemigo4
    def redraGameWindow(): #----------------------------------------------------------------------Esta funcion pinta el mundo/mejor dicho, realcia nuestras impresiones de frames
        if thief.visible == False and thief2.visible == False and thief3.visible == False and thief4.visible == False:
            win.blit(miami,(0,0))
            text = font.render("PUNTAJE: " + str(puntaje4),1,(0,255,0))
            win.blit(text, (450,10))
        else:
            win.blit(bg,(0,0))
            text = font.render("PUNTAJE: " + str(puntaje4),1,(255,0,32))
            win.blit(text, (450,10))
        eugeo.draw(win)
        thief.draw(win)
        thief2.draw(win)
        thief3.draw(win)
        thief4.draw(win)
        for bullet in bullets:
            bullet.draw(win)
        # win.fill((0,0,0))

        
        pygame.display.update()

    #main loop
    font = pygame.font.SysFont ("comicsans",30,True)
    thief = enemy(100,415,64,64,450)
    thief2 = enemy2(600,415,64,64,1000)
    thief3 = enemy3(500,415,64,64,800)
    thief4 = enemy4(0,415,64,64,1000)
    eugeo = player(300,410,64,46)
    shootLoop = 0
    bullets = [] #-----------------------------------------------------------------------------------------esta lista contiene nuestras balas
    run = True 
    while run:
        #pygame.time.delay(10)
        clock.tick(50)
        

        if thief.visible == True:

            
            if eugeo.hitbox[1]  < thief.hitbox[1] + thief.hitbox[3] and eugeo.hitbox[1] + eugeo.hitbox[3]> thief.hitbox[1]:
                        if eugeo.hitbox[0] + eugeo.hitbox[2]  > thief.hitbox[0] and eugeo.hitbox[0] < thief.hitbox[0] + thief.hitbox[2]:
                            eugeo.hit()
                            puntaje4 -= 5

        if shootLoop > 0:
            shootLoop += 1
        if shootLoop > 0:
            shootLoop = 0


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
        for bullet in bullets:#------------------------------------------------------------------------------------------------disparamos las balas y detectamos cuando estas le dan a el ladrón
            if thief.visible == True:
                if bullet.y - bullet.radio < thief.hitbox[1] + thief.hitbox[3] and bullet.y + bullet.radio > thief.hitbox[1]:
                    if bullet.x + bullet.radio > thief.hitbox[0] and bullet.x - bullet.radio < thief.hitbox[0] + thief.hitbox[2]:
                        hitSound.play()
                        puntaje4 += 1
                        thief.hit()
                        bullets.pop(bullets.index(bullet))
        #=============================================================================================================thief2
        if thief2.visible == True:

            
            if eugeo.hitbox[1]  < thief2.hitbox[1] + thief2.hitbox[3] and eugeo.hitbox[1] + eugeo.hitbox[3]> thief2.hitbox[1]:
                        if eugeo.hitbox[0] + eugeo.hitbox[2]  > thief2.hitbox[0] and eugeo.hitbox[0] < thief2.hitbox[0] + thief2.hitbox[2]:
                            eugeo.hit()
                            puntaje4 -= 5
        for bullet in bullets:#------------------------------------------------------------------------------------------------disparamos las balas y detectamos cuando estas le dan a el ladrón
            if thief2.visible == True:
                if bullet.y - bullet.radio < thief2.hitbox[1] + thief2.hitbox[3] and bullet.y + bullet.radio > thief2.hitbox[1]:
                    if bullet.x + bullet.radio > thief2.hitbox[0] and bullet.x - bullet.radio < thief2.hitbox[0] + thief2.hitbox[2]:
                        hitSound.play()
                        puntaje4 += 1
                        thief2.hit()
                        bullets.pop(bullets.index(bullet))

        #=============================================================================================================thief2

            #=============================================================================================================thief3
        if thief3.visible == True:

            
            if eugeo.hitbox[1]  < thief3.hitbox[1] + thief3.hitbox[3] and eugeo.hitbox[1] + eugeo.hitbox[3]> thief3.hitbox[1]:
                        if eugeo.hitbox[0] + eugeo.hitbox[2]  > thief3.hitbox[0] and eugeo.hitbox[0] < thief3.hitbox[0] + thief3.hitbox[2]:
                            eugeo.hit()
                            puntaje4 -= 5
        for bullet in bullets:#------------------------------------------------------------------------------------------------disparamos las balas y detectamos cuando estas le dan a el ladrón
            if thief3.visible == True:
                if bullet.y - bullet.radio < thief3.hitbox[1] + thief3.hitbox[3] and bullet.y + bullet.radio > thief3.hitbox[1]:
                    if bullet.x + bullet.radio > thief3.hitbox[0] and bullet.x - bullet.radio < thief3.hitbox[0] + thief3.hitbox[2]:
                        hitSound.play()
                        puntaje4 += 1
                        thief3.hit()
                        bullets.pop(bullets.index(bullet))

        #=============================================================================================================thief3

                #=============================================================================================================thief4
        if thief4.visible == True:

            
            if eugeo.hitbox[1]  < thief4.hitbox[1] + thief4.hitbox[3] and eugeo.hitbox[1] + eugeo.hitbox[3]> thief4.hitbox[1]:
                        if eugeo.hitbox[0] + eugeo.hitbox[2]  > thief4.hitbox[0] and eugeo.hitbox[0] < thief4.hitbox[0] + thief4.hitbox[2]:
                            eugeo.hit()
                            puntaje4 -= 5
        for bullet in bullets:#------------------------------------------------------------------------------------------------disparamos las balas y detectamos cuando estas le dan a el ladrón
            if thief4.visible == True:
                if bullet.y - bullet.radio < thief4.hitbox[1] + thief4.hitbox[3] and bullet.y + bullet.radio > thief4.hitbox[1]:
                    if bullet.x + bullet.radio > thief4.hitbox[0] and bullet.x - bullet.radio < thief4.hitbox[0] + thief4.hitbox[2]:
                        hitSound.play()
                        puntaje4 += 1
                        thief4.hit()
                        bullets.pop(bullets.index(bullet))

        #=============================================================================================================thief4

            if bullet.x < 1000 and bullet.x > 0:
                bullet.x += bullet.vel
            else:
                bullets.pop(bullets.index(bullet))

        Keys = pygame.key.get_pressed()   #---------------------------------------------------------------------------las teclas que se utilizan en nuestro programa
        if Keys[pygame.K_SPACE] and shootLoop == 0:
            bulletSound.play()
            if eugeo.left:
                cara = -1
            else: 
                cara = 1
            if len(bullets) < 5:  
                bullets.append(projectile(round(eugeo.x + eugeo.width//2), round(eugeo.y + eugeo.height//2), 6, (50,141,216), cara ))
            shootLoop = 1

        
        if Keys[pygame.K_LEFT] and eugeo.x > eugeo.vel:
            eugeo.x -= eugeo.vel
            eugeo.left = True
            eugeo.right = False
            eugeo.standing = False
        elif Keys[pygame.K_RIGHT] and eugeo.x < 1000 -eugeo.width - eugeo.vel:
            eugeo.x += eugeo.vel
            eugeo.left = False
            eugeo.right = True
            eugeo.standing = False
        else:
            eugeo.standing = True
            eugeo.walkCount = 0

        if not(eugeo.isJump):
            if Keys[pygame.K_UP]:
                eugeo.isJump = True
                #eugeo.left = False
                #eugeo.right = False
                eugeo.walkCount = 0
        else:  #---------------------------------------------------------------------------------------------------SALTO
            if eugeo.jumpCount >= -10:
                neg = 1
                if eugeo.jumpCount < 0:
                    neg = -1
                eugeo.y -= (eugeo.jumpCount ** 2) *0.4 * neg
                eugeo.jumpCount -=1
            else:
                eugeo.isJump = False
                eugeo.jumpCount = 10

        redraGameWindow() #------------------------------------------------------------------------------------------En esta funcion se encuentran nuestros "Draw (dibujos)"
        
        
    pygame.quit()