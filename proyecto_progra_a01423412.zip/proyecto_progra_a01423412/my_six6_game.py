import pygame
pygame.init()

win = pygame.display.set_mode((1000,480))

pygame.display.set_caption("first game")

walkRight = [pygame.image.load('R1.png'), pygame.image.load('R2.png'), pygame.image.load('R3.png'), pygame.image.load('R4.png'), pygame.image.load('R5.png'), pygame.image.load('R6.png'), pygame.image.load('R7.png'), pygame.image.load('R8.png'), pygame.image.load('R9.png')]
walkLeft = [pygame.image.load('L1.png'), pygame.image.load('L2.png'), pygame.image.load('L3.png'), pygame.image.load('L4.png'), pygame.image.load('L5.png'), pygame.image.load('L6.png'), pygame.image.load('L7.png'), pygame.image.load('L8.png'), pygame.image.load('L9.png')]
bg = pygame.image.load('background.jpg')
char = pygame.image.load('standing.png')

clock = pygame.time.Clock() #---------------------------------------------------------Change the FPS of the GAME
 
class player(object):   #-----------------------------------------------------------------Metimos todas nuestras variables que definen a nuestro jugados en una clase llamada player y ahora son un atrivuto de nuestra clase
    def __init__(self,x,y,width,height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 5
        self.isJump = False
        self.jumpCount = 10
        self.left = False
        self.right = False
        self.walkCount = 0
        self.standing = True
        self.hitbox = (self.x + 20, self.y, 28,60)


    def draw(self,win): #--------------------------------------------------------------------------------funcion donde dibujamos a nuestro personaje
        if not(self.standing):
            if self.walkCount + 1 >= 27:
                self.walkCount = 0
            
            if self.left:
                win.blit(walkLeft[self.walkCount//3], (self.x,self.y)) 
                self.walkCount += 1
            elif self.right:
                win.blit(walkRight[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
        else:
            if self.right:
                win.blit(walkRight[0], (self.x,self.y))
            else:
                win.blit(walkLeft[0], (self.x,self.y))

class projectile(object): #----------------------------------------------------------------------------------creamos nuestra clase de proyectil para poder definir nuestra bala
    def __init__(self,x,y,radio,color,cara):#---------------------------------------------------------------cara sirve para decirnos si nmuestras balas se mueven izquierda o derecha
        self.x = x
        self.y = y
        self.radio = radio
        self.color = color
        self.cara = cara
        self.vel = 8*cara
    def draw(self,win):#---------------------------------------------------------------------------------------dibujamos la bala
        pygame.draw.circle(win,self.color,(self.x,self.y),self.radio)


class enemy(object): #--------------------------------------------------------------------------------------------creamos a nuestro enemigo del juego 
    walkRight = [pygame.image.load('R1E.png'), pygame.image.load('R2E.png'), pygame.image.load('R3E.png'), pygame.image.load('R4E.png'), pygame.image.load('R5E.png'), pygame.image.load('R6E.png'), pygame.image.load('R7E.png'), pygame.image.load('R8E.png'), pygame.image.load('R9E.png'), pygame.image.load('R10E.png'), pygame.image.load('R11E.png')]
    walkLeft = [pygame.image.load('L1E.png'), pygame.image.load('L2E.png'), pygame.image.load('L3E.png'), pygame.image.load('L4E.png'), pygame.image.load('L5E.png'), pygame.image.load('L6E.png'), pygame.image.load('L7E.png'), pygame.image.load('L8E.png'), pygame.image.load('L9E.png'), pygame.image.load('L10E.png'), pygame.image.load('L11E.png')]
    
    def __init__(self,x,y,width,height,end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.path = [self.x,self.end]
        self.walkCount = 0
        self.vel = 3
    def draw(self,win): #----------------------------------------------------------------------------------------------dibujamos al enemigo
        self.move()
        if self.walkCount +1 >= 33:
            self.walkCount = 0
        if self.vel > 0:
            win.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
            self.walkCount += 1
        else:
            win.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
            self.walkCount += 1

            



    def move(self):
        if self.vel > 0: #---------------------------nuestro enemigo va a la derecha
            if self.x +self.vel < self.path[1]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1  
                self.walkCount = 0
        else:  #-----------------------------------nuestro enemigo va a la izquierda 
            if self.x - self.vel > self.path[0]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0

       


def redraGameWindow(): #----------------------------------------------------------------------Esta funcion pinta el mundo/mejor dicho, realcia nuestras impresiones de frames
    win.blit(bg,(0,0))
    eugeo.draw(win)
    thief.draw(win)
    for bullet in bullets:
        bullet.draw(win)
    # win.fill((0,0,0))

    
    pygame.display.update()

#main loop
thief = enemy(100,415,64,64,450)
eugeo = player(300,410,64,46)
bullets = [] #-----------------------------------------------------------------------------------------esta lista contiene nuestras balas
run = True 
while run:
    #pygame.time.delay(10)
    clock.tick(50)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    for bullet in bullets:
        if bullet.x < 1000 and bullet.x > 0:
            bullet.x += bullet.vel
        else:
            bullets.pop(bullets.index(bullet))
    Keys = pygame.key.get_pressed()   #---------------------------------------------------------------------------las teclas que se utilizan en nuestro programa
    if Keys[pygame.K_SPACE]:
        if eugeo.left:
            cara = -1
        else: 
            cara = 1
        if len(bullets) < 1000:  
            bullets.append(projectile(round(eugeo.x + eugeo.width//2), round(eugeo.y + eugeo.height//2), 6, (0,0,0), cara ))


    
    if Keys[pygame.K_LEFT] and eugeo.x > eugeo.vel:
        eugeo.x -= eugeo.vel
        eugeo.left = True
        eugeo.right = False
        eugeo.standing = False
    elif Keys[pygame.K_RIGHT] and eugeo.x < 1000 -eugeo.width - eugeo.vel:
        eugeo.x += eugeo.vel
        eugeo.left = False
        eugeo.right = True
        eugeo.standing = False
    else:
        eugeo.standing = True
        eugeo.walkCount = 0

    if not(eugeo.isJump):
        if Keys[pygame.K_UP]:
            eugeo.isJump = True
            #eugeo.left = False
            #eugeo.right = False
            eugeo.walkCount = 0
    else:  #---------------------------------------------------------------------------------------------------SALTO
        if eugeo.jumpCount >= -10:
            neg = 1
            if eugeo.jumpCount < 0:
                neg = -1
            eugeo.y -= (eugeo.jumpCount ** 2) *0.4 * neg
            eugeo.jumpCount -=1
        else:
            eugeo.isJump = False
            eugeo.jumpCount = 10

    redraGameWindow() #------------------------------------------------------------------------------------------En esta funcion se encuentran nuestros "Draw (dibujos)"
    
    
pygame.quit()